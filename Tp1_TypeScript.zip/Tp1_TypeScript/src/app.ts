let currentInput: string = "";
let operator: string | null = null;
let previousInput: string = "";

const screenElement: HTMLElement | null = document.getElementById("screen");

function appendNumber(number: string): void {
    currentInput += number;
    updateScreen();
}

function setOperator(op: string): void {
    if (currentInput === "") return;

    if (operator !== null) {
        calculate(); // Calculer le résultat si un opérateur est déjà défini
    }
    
    operator = op;
    previousInput = currentInput;
    currentInput = "";
}

function calculate(): void {
    let computation: string | number;
    const prev: number = parseFloat(previousInput);
    const current: number = parseFloat(currentInput);

    if (isNaN(prev) || isNaN(current)) return;

    switch (operator) {
        case "+":
            computation = prev + current;
            break;
        case "-":
            computation = prev - current;
            break;
        case "*":
            computation = prev * current;
            break;
        case "/":
            if (current === 0) {
                computation = "Math Error"; // Message d'erreur pour division par zéro
            } else {
                computation = prev / current;
            }
            break;
        default:
            return;
    }

    currentInput = computation.toString();
    operator = null; // Réinitialiser l'opérateur après le calcul
    previousInput = ""; // Réinitialiser l'entrée précédente
    updateScreen();
}

function updateScreen(): void {
    if (screenElement) {
        screenElement.textContent = currentInput || "0";
    }
}

// Ajoutez ici les écouteurs d'événements pour les boutons
document.querySelectorAll('.button').forEach(button => {
    button.addEventListener('click', () => {
        const value = (button as HTMLButtonElement).textContent;
        if (!isNaN(Number(value))) {
            appendNumber(value!);
        } else if (value === "C") {
            currentInput = "";
            previousInput = "";
            operator = null;
            updateScreen();
        } else if (value === "=") {
            calculate();
        } else {
            setOperator(value!);
        }
    });
});